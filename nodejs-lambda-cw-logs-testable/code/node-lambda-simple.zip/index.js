'use strict'

module.exports.handler = async (event) => {
    console.log('Received event:', event);
}